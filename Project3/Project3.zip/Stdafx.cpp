#include "Stdafx.h"
//vector<Bullet> pVBullets;
//vector<Drops> vDrops;

